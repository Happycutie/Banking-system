package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class CashierScreenController {

	Bank m = new Bank();
	
    @FXML
    private Button deposit;

    @FXML
    private Button logout;

    @FXML
    private Button transfer;

    @FXML
    private Button withdraw;

    @FXML
    void depositMoney(ActionEvent event) throws IOException {
    	Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

    	m.depositMoney(s);
    }

    @FXML
    void start(ActionEvent event) throws IOException{
    	// the stage can be accessed using action event source
    	Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

    	m.start(s);
    }

    @FXML
    void transferAmount(ActionEvent event) throws IOException {
    	Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

    	m.transferAmount(s);
    }

    @FXML
    void withdrawMoney(ActionEvent event) throws IOException {
    	Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

    	m.withdrawMoney(s);
    }

}