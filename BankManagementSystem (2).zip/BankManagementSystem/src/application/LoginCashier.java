package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginCashier {

	Bank m = new Bank();

	@FXML
	private Button cancel;

	@FXML
	private PasswordField password;

	@FXML
	private Label passwordError;

	@FXML
	private Button login;

	@FXML
	private TextField username;

	@FXML
	void start(ActionEvent event) {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.start(s);

	}

	@FXML
	void mainPageOfCashier(ActionEvent event) throws IOException {

		String name = username.getText();

		String pass = password.getText();

		System.out.println(name + "," + pass);

		boolean check = false;

		for (int i = 0; i < DatabaseLedger.getCashier().size(); i++) {

			if ((DatabaseLedger.getCashier().get(i).getUsername().equals(name))
					&& (DatabaseLedger.getCashier().get(i).getPassword().equals(pass))) {

				check = true;

				// the stage can be accessed using action event source Stage s = (Stage)
				Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

				m.MainScreenCashier(s);
			}

		}

		if (check == false) {
			passwordError.setText("Username/Password is not correct");
		}
	}

}
