package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class AccountHolderUserInfoController {

	Bank m = new Bank();
	@FXML
	private Button userInfo;


    @FXML
    private Button viewTransection;

    @FXML
    private Button back;
  
    @FXML
    private Label userInfoBalance;
    
    
    @FXML
    private Label userInfoCNIC;
    
    @FXML
    private Label userInfoPhoneNumber;
    
    @FXML
    private Label userInfoName;

    @FXML
    private Label userInfoAddress;

    @FXML
    private Label userInfoUserName;

    @FXML
    private Label userInfoGender;

    @FXML
    private Label userInfoAccounttype;
    
    
    @FXML
    private Label userInfoCustomerType;
    
    
    

    @FXML
    private Button checkBalance;


    @FXML
    void userInfo(ActionEvent event) throws IOException {

    	setUserInfo();
    	
    	Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();
		m.MoveToUserInfo(s);
    	
    }

    @FXML
    void backToMain(ActionEvent event) throws IOException {
    	Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();
		m.MainScreenAccountHolder(s);
    }
	
    
    public void setUserInfo() {
    	
    	userInfoAccounttype.setText(DatabaseLedger.accounts.get(LoginAccountHolder.index).getAccountHolder().getAccountType());
    	userInfoCustomerType.setText(DatabaseLedger.accounts.get(LoginAccountHolder.index).getAccountHolder().getCustomerType());
    	userInfoBalance.setText(DatabaseLedger.accounts.get(LoginAccountHolder.index).getBalance()+"");
    	userInfoCNIC.setText(DatabaseLedger.accounts.get(LoginAccountHolder.index).getAccountHolder().getCnic());
    	userInfoPhoneNumber.setText(DatabaseLedger.accounts.get(LoginAccountHolder.index).getAccountHolder().getPhoneNo());
    	userInfoName.setText(DatabaseLedger.accounts.get(LoginAccountHolder.index).getAccountHolder().getName());
    	userInfoAddress.setText(DatabaseLedger.accounts.get(LoginAccountHolder.index).getAccountHolder().getAddress());
    	userInfoUserName.setText(DatabaseLedger.accounts.get(LoginAccountHolder.index).getAccountHolder().getUsername());
    	userInfoGender.setText(DatabaseLedger.accounts.get(LoginAccountHolder.index).getAccountHolder().getGender());
    	    	
    }
    
}
