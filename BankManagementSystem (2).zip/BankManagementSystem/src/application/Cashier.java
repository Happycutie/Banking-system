package application;

public class Cashier extends User {

	private String username;

	private String gender;

	private double salary;

	private String hiringDate;

	public Cashier(String name, String password, String gender, String address, String cnic, String phoneNo, double salary, String hiringDate, String username) {
		super(name, password, phoneNo, address, cnic);
		this.salary = salary;
		this.gender = gender;
		this.username = username;
		this.hiringDate = hiringDate;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getHiringDate() {
		return hiringDate;
	}

	public void setHiringDate(String hiringDate) {
		this.hiringDate = hiringDate;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

}
