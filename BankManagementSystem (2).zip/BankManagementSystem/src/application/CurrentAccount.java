package application;

public interface CurrentAccount {

}
