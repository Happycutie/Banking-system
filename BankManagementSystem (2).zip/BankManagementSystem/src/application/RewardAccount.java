package application;

public class RewardAccount extends Account {

	@Override
	public int makeDeposit(double amount) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int makeWithDrawal(double amount) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int transferAmount(double amount, Account account) {
		// TODO Auto-generated method stub
		return 0;
	}

}
