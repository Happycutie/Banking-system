package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class DepositController {

	Bank m = new Bank();
	static int searchIndex = -1;

	@FXML
	private Button Deposit;

	@FXML
	private Label accountNumber;

	@FXML
	private Label accountType;

	@FXML
	private Button back;

	@FXML
	private Label currentBalance;

	@FXML
	private TextField depositAmount;

	@FXML
	private Label messageAfterDeposit;

	@FXML
	private Label messageIfAccNotFound;

	@FXML
	private Button search;

	@FXML
	private TextField throughAccountNumber;

	@FXML
	private TextField throughCNICNumber;

	@FXML
	void depositAmount(ActionEvent event) throws IOException {

		double amount = Double.parseDouble(depositAmount.getText());

		if (searchIndex >= 0) {

			int dValue = m.deposit(searchIndex, amount);

			if (dValue == 1) {
				messageAfterDeposit.setText("Amount is deposited successfully!");
			} else {
				messageAfterDeposit.setText("Amount can't be negative!!");
			}

		}
	}

	@FXML
	void depositSearch(ActionEvent event) {

		String accountNum = throughAccountNumber.getText();
		String cnic = throughCNICNumber.getText();
		searchIndex = -1;

		try {

			if ((!(accountNum.isBlank()) && cnic.isBlank()) || (!(cnic.isBlank()) && accountNum.isBlank())) {

				if ((!(accountNum.isBlank()))) {

					Account a = m.deposit_Search(accountNum, cnic);

					if (a != null) {
						accountNumber.setText(a.getAccountHolder().getAccountNumber());
						accountType.setText(a.getAccountHolder().getAccountType());
						currentBalance.setText(String.valueOf(a.getBalance()));

						messageIfAccNotFound.setText("");
						return;

					} else {
						messageIfAccNotFound.setText("No Account exists");
					}
				}

				else if ((!(cnic.isBlank()))) {

					Account a = m.deposit_Search(accountNum, cnic);

					if (a != null) {
						accountNumber.setText(a.getAccountHolder().getAccountNumber());
						accountType.setText(a.getAccountHolder().getAccountType());
						currentBalance.setText(String.valueOf(a.getBalance()));

						messageIfAccNotFound.setText("");
						return;

					} else {
						messageIfAccNotFound.setText("No Account exists");
					}
				}
			} else {
				accountNumber.setText("");
				accountType.setText("");
				currentBalance.setText("");
				messageIfAccNotFound.setText("Please!! Search through Account Number or CNIC Number");
			}

		} catch (Exception e) {
			e.printStackTrace();
//		} finally {
//			if (searchIndex == -1)
//				messageIfAccNotFound.setText("No Account exists");
		}
	}

	@FXML
	void goToCashierMainScreen(ActionEvent event) throws IOException {
		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.MainScreenCashier(s);
	}

}