package application;

import java.util.List;

public class AccountHolder extends User {

	private String username;

	private String gender;

	private String dateOfBirth;

	private String accountNumber;

	private String accountType;
	
	private String customerType;
	
	private String creationDate;
	
	 private List<CustomerType> customerTypes;

	
	public AccountHolder(String name, String password, String phoneNo, String address, String cnic) {
		super(name, password, phoneNo, address, cnic);
	}

	public AccountHolder(String name, String password, String phoneNo, String address, String cnic, String username, String gender,
			String dateOfBirth, String accountNumber, String accountType,String customerType, String creationDate, List<CustomerType> customerTypes) {
		super(name, password, phoneNo, address, cnic);
		this.username = username;
		this.gender = gender;
		this.dateOfBirth = dateOfBirth;
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.customerTypes = customerTypes;
		this.customerType = customerType;
		this.creationDate = creationDate;
	}

	public AccountHolder() {
		// TODO Auto-generated constructor stub
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountType() {
		return accountType;
	}
	
	
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	
	public String getCustomerType() {
		return customerType;
	}
	
	public void setCustomerType(String customerType) {
	    this.customerType = customerType;
	}
	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public List<CustomerType> getCustomerTypes() {
		return customerTypes;
	}

	public void setCustomerTypes(List<CustomerType> customerTypes) {
		this.customerTypes = customerTypes;
	}

}
