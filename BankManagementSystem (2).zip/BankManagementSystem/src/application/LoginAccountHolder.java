package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginAccountHolder {

	Bank m = new Bank();

  static int index;
	static String usernameTrack = " ";
//	static String accountNumberTrack = " ";

//	private String usernameTrack = " ";
//	private String accountNumberTrack = " ";
//	private int index;
	

	@FXML
	private Button cancel;

	@FXML
	private PasswordField password;

	@FXML
	private Label Error;

	@FXML
	private Button login;

	@FXML
	private TextField username;

	@FXML
	public void start(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.start(s);

	}

	@FXML
	void mainPageOfAccountHolder(ActionEvent event) throws IOException {

		String name = username.getText();

		String pass = password.getText();

		System.out.println(name + "," + pass + " Hello");

		boolean check = false;

		for (int i = 0; i < DatabaseLedger.getAccounts().size(); i++) {

			DatabaseLedger.accounts.get(i).getAccountHolder().getUsername();

			if ((DatabaseLedger.accounts.get(i).getAccountHolder().getUsername().equals(name))
					&& (DatabaseLedger.accounts.get(i).getAccountHolder().getPassword().equals(pass))) {

				LoginAccountHolder.index = i ;
				LoginAccountHolder.usernameTrack = name;
//				LoginAccountHolder.accountNumberTrack = Database.accounts.get(i).getAccountHolder().getAccountNumber();
				
				
//				LoginAccountHolder.setIndex(i);
//				LoginAccountHolder.usernameTrack = name;
//				LoginAccountHolder.accountNumberTrack = Database.accounts.get(i).getAccountHolder().getAccountNumber();
				System.out.println("Hellllllo");
				check = true;
				Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();
				m.MainScreenAccountHolder(s);
				break;
			}
		}

		if (check == false) {
			Error.setText("Username or Password doesn't match");
			System.out.println("He");
//			Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();
//			m.MainScreenAccountHolder(s);
		}
	}

}
