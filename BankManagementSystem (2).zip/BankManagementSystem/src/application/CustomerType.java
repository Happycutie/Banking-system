package application;

public enum CustomerType {

	 INDIVIDUAL,

	  BUSINESS,

	  CHARITY

	}
