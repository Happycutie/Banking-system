package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class TransferMoneyController {

	Bank m = new Bank();

	static int sIndex = -1, rIndex = -1;

	@FXML
	private Button RecieverSearch;

	@FXML
	private TextField RecieverAccount;

	@FXML
	private Button Search;

	@FXML
	private TextField SenderAccount;

	@FXML
	private Label SenderBalance;

	@FXML
	private Button back;

	@FXML
	private Label messageAfterTransfer;

	@FXML
	private Label receiverAccountError;

	@FXML
	private Label senderAccountError;

	@FXML
	private Button transfer;

	@FXML
	private TextField transferAmount;

	@FXML
	private Label bothEqualError;

	@FXML
	void goToCashierMainScreen(ActionEvent event) throws IOException {
		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.MainScreenCashier(s);
	}

	@FXML
	void transferAmount(ActionEvent event) throws IOException {

		double amount = Double.parseDouble(transferAmount.getText());

		if (sIndex >= 0 && rIndex >= 0) {

			int tValue = m.transferBalance(amount, sIndex, rIndex);

			if (tValue == 1) {
				messageAfterTransfer.setText("Amount is transferred successfully!");
			} else {
				messageAfterTransfer.setText("Amount is more than Sender's balance");
			}

		}
	}

	@FXML
	void ReciverTransferSearch(ActionEvent event) {

		String senderAccountNum = SenderAccount.getText();
		String reciverAccountNum = RecieverAccount.getText();

		String balance = m.transferSearch(senderAccountNum, reciverAccountNum);

		if (!(senderAccountNum.isBlank())) {

			if (!(reciverAccountNum.isBlank())) {

				if (!(reciverAccountNum.equals(senderAccountNum))) {

					SenderBalance.setText(balance);

				} else {
					receiverAccountError.setText("");
					senderAccountError.setText("");
					bothEqualError.setText("Account numbers cannot be same");
				}

			} else {
				receiverAccountError.setText("please fill out receiver account number");
				senderAccountError.setText("");
			}
		} else {
			senderAccountError.setText("please fill out sender account number");
		}
	}

}